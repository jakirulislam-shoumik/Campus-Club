/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: "#14213d", 700: "#1d2e52", 900: "#0d1630" },
        brass: { DEFAULT: "#a9852e", light: "#c9a85a", dark: "#86671d" },
        paper: "#eef1f6",
        ok: "#1f7a43",
        warn: "#b26a00",
        bad: "#b3261e",
      },
      fontFamily: {
        heading: ["Fraunces", "Georgia", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
    },
  },
  plugins: [],
};
