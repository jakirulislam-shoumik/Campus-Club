import { useState } from "react";
import { ClipboardList } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, formatDate } from "@/lib/utils";
import type { ClubEvent, RegistrationAdminRow } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import { Stamp } from "@/components/ui/stamp";

export default function EventRegistrations() {
  const [eventId, setEventId] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, loading, error, reload } = useQuery(async () => {
    const [registrations, events] = await Promise.all([
      unwrap<RegistrationAdminRow[]>(
        supabase
          .from("event_registrations")
          .select("*, students(name, email), events(event_name, event_date)")
          .order("registration_date", { ascending: false }),
      ),
      unwrap<Pick<ClubEvent, "event_id" | "event_name" | "event_date">[]>(
        supabase.from("events").select("event_id, event_name, event_date").order("event_date", { ascending: false }),
      ),
    ]);
    return { registrations, events };
  });

  async function markAttended(r: RegistrationAdminRow) {
    setBusyId(r.registration_id);
    try {
      await unwrap(supabase.from("event_registrations").update({ status: "Attended" }).eq("registration_id", r.registration_id));
      toast.success("Marked attended");
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  const rows = data ? data.registrations.filter((r) => !eventId || r.event_id === eventId) : [];

  return (
    <>
      <PageHeader eyebrow="Administration" title="Event Registrations" description="Every registration across all events. Mark students as attended after the event." />

      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load registrations."} onRetry={reload} />
      ) : (
        <>
          <div className="mb-4 max-w-sm">
            <label htmlFor="event-filter" className="mb-1.5 block text-sm font-medium">
              Filter by event
            </label>
            <Select id="event-filter" value={eventId} onChange={(e) => setEventId(e.target.value)}>
              <option value="">All events</option>
              {data.events.map((ev) => (
                <option key={ev.event_id} value={ev.event_id}>
                  {ev.event_name} ({formatDate(ev.event_date)})
                </option>
              ))}
            </Select>
          </div>

          {rows.length === 0 ? (
            <EmptyState
              icon={ClipboardList}
              title={eventId ? "No registrations for this event" : "No registrations yet"}
              action={
                eventId ? (
                  <Button variant="outline" onClick={() => setEventId("")}>
                    Show all events
                  </Button>
                ) : undefined
              }
            >
              {eventId ? "Nobody has registered for this event yet. Try another event, or show all." : "Registrations will appear here as students sign up for events."}
            </EmptyState>
          ) : (
            <div className="table-wrap">
              <table className="ledger-table">
                <thead>
                  <tr>
                    <th scope="col">Student</th>
                    <th scope="col">Event</th>
                    <th scope="col">Registered</th>
                    <th scope="col">Status</th>
                    <th scope="col">Feedback</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.registration_id}>
                      <td data-label="Student">
                        <span className="font-medium">{r.students?.name ?? "Unknown student"}</span>
                        <span className="block break-all text-xs text-navy/70">{r.students?.email}</span>
                      </td>
                      <td data-label="Event">
                        {r.events?.event_name ?? "—"}
                        {r.events && <span className="mono-label block">{formatDate(r.events.event_date)}</span>}
                      </td>
                      <td data-label="Registered">{formatDate(r.registration_date)}</td>
                      <td data-label="Status">
                        <Stamp status={r.status} />
                      </td>
                      <td data-label="Feedback" className="max-w-xs text-xs text-navy/80">
                        {r.feedback ?? "—"}
                      </td>
                      <td data-label="Action">
                        {r.status === "Registered" ? (
                          <Button variant="success" size="sm" loading={busyId === r.registration_id} onClick={() => markAttended(r)}>
                            Mark attended
                          </Button>
                        ) : (
                          <span className="text-xs text-navy/70">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
