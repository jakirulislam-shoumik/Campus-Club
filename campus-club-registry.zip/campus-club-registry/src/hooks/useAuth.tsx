import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

type Role = "admin" | "student";

interface AuthState {
  user: User | null;
  session: Session | null;
  roles: Role[];
  isAdmin: boolean;
  displayName: string;
  loading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [displayName, setDisplayName] = useState("");
  const [sessionLoading, setSessionLoading] = useState(true);
  // Id of the user whose roles have been loaded; avoids a render where a new session has no roles yet.
  const [rolesFor, setRolesFor] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setSessionLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const userId = session?.user.id;

  // Roles come from user_roles only. Loaded outside the auth callback to avoid auth-client deadlocks.
  useEffect(() => {
    if (!userId) {
      setRoles([]);
      setDisplayName("");
      setRolesFor(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data: roleRows } = await supabase.from("user_roles").select("role").eq("user_id", userId);
      const nextRoles = ((roleRows ?? []) as { role: Role }[]).map((r) => r.role);
      const isAdmin = nextRoles.includes("admin");
      const table = isAdmin ? "admins" : "students";
      const idCol = isAdmin ? "admin_id" : "student_id";
      const { data: profile } = await supabase.from(table).select("name").eq(idCol, userId).maybeSingle();
      if (cancelled) return;
      setRoles(nextRoles);
      setDisplayName((profile as { name?: string } | null)?.name ?? session?.user.email ?? "");
      setRolesFor(userId);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const value = useMemo<AuthState>(
    () => ({
      user: session?.user ?? null,
      session,
      roles,
      isAdmin: roles.includes("admin"),
      displayName,
      loading: sessionLoading || (userId !== undefined && rolesFor !== userId),
      signOut: async () => {
        await supabase.auth.signOut();
      },
    }),
    [session, roles, displayName, sessionLoading, rolesFor, userId],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
