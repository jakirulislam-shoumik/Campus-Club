import { useState } from "react";
import { Plus, Users } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, shortId } from "@/lib/utils";
import type { Club, ClubWithCounts } from "@/lib/types";
import { ClubFormDialog } from "@/components/admin/ClubFormDialog";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Stamp } from "@/components/ui/stamp";

export default function AdminClubs() {
  const [editing, setEditing] = useState<Club | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, loading, error, reload } = useQuery(() =>
    unwrap<ClubWithCounts[]>(supabase.from("clubs").select("*, memberships(status)").order("club_name")),
  );

  function openForm(club: Club | null) {
    setEditing(club);
    setFormOpen(true);
  }

  async function toggleStatus(club: Club) {
    const next = club.status === "Active" ? "Inactive" : "Active";
    setBusyId(club.club_id);
    try {
      await unwrap(supabase.from("clubs").update({ status: next }).eq("club_id", club.club_id));
      toast.success(next === "Active" ? "Activated" : "Deactivated");
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Administration"
        title="Clubs"
        description="Create and edit clubs, and switch them on or off. Inactive clubs disappear for students."
        action={
          <Button variant="brass" onClick={() => openForm(null)}>
            <Plus className="h-4 w-4" aria-hidden="true" />
            New club
          </Button>
        }
      />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load clubs."} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No clubs yet"
          action={
            <Button variant="brass" onClick={() => openForm(null)}>
              New club
            </Button>
          }
        >
          Create the first club so students can start requesting to join.
        </EmptyState>
      ) : (
        <div className="table-wrap">
          <table className="ledger-table">
            <thead>
              <tr>
                <th scope="col">Club</th>
                <th scope="col">Category</th>
                <th scope="col">Contact</th>
                <th scope="col">Active members</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.map((club) => (
                <tr key={club.club_id}>
                  <td data-label="Club">
                    <span className="font-medium">{club.club_name}</span>
                    <span className="mono-label block">{shortId(club.club_id)}</span>
                  </td>
                  <td data-label="Category">{club.category}</td>
                  <td data-label="Contact" className="break-all">
                    {club.email}
                  </td>
                  <td data-label="Active members" className="font-mono">
                    {club.memberships.filter((m) => m.status === "Active").length}
                  </td>
                  <td data-label="Status">
                    <Stamp status={club.status} />
                  </td>
                  <td data-label="Actions">
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" onClick={() => openForm(club)}>
                        Edit
                      </Button>
                      <Button
                        variant={club.status === "Active" ? "dangerOutline" : "outline"}
                        size="sm"
                        loading={busyId === club.club_id}
                        onClick={() => toggleStatus(club)}
                      >
                        {club.status === "Active" ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <ClubFormDialog
        open={formOpen}
        club={editing}
        onClose={() => setFormOpen(false)}
        onSaved={() => {
          setFormOpen(false);
          reload();
        }}
      />
    </>
  );
}
