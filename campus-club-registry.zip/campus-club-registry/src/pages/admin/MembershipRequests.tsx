import { useState } from "react";
import { Inbox } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { notifyMembershipsChanged } from "@/lib/events";
import { errorMessage, formatDate } from "@/lib/utils";
import type { MembershipStatus, MembershipWithRefs } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import { Stamp } from "@/components/ui/stamp";

const ORDER: Record<MembershipStatus, number> = { Pending: 0, Active: 1, Rejected: 2 };

export default function MembershipRequests() {
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, loading, error, reload } = useQuery(async () => {
    const rows = await unwrap<MembershipWithRefs[]>(
      supabase.from("memberships").select("*, students(name, email, department, semester), clubs(club_name)"),
    );
    // Pending first, then newest first within each group.
    return rows.sort((a, b) => ORDER[a.status] - ORDER[b.status] || b.join_date.localeCompare(a.join_date));
  });

  async function decide(m: MembershipWithRefs, status: "Active" | "Rejected") {
    setBusyId(m.membership_id);
    try {
      await unwrap(supabase.from("memberships").update({ status }).eq("membership_id", m.membership_id));
      toast.success(status === "Active" ? "Approved" : "Rejected");
      notifyMembershipsChanged();
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  async function changeRole(m: MembershipWithRefs, role: string) {
    setBusyId(m.membership_id);
    try {
      await unwrap(supabase.from("memberships").update({ role_in_club: role }).eq("membership_id", m.membership_id));
      toast.success("Role updated");
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Administration" title="Membership Requests" description="Pending requests are listed first. Approve or reject each one." />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load requests."} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState icon={Inbox} title="No requests yet">
          When students request to join a club, their requests will show up here for review.
        </EmptyState>
      ) : (
        <div className="table-wrap">
          <table className="ledger-table">
            <thead>
              <tr>
                <th scope="col">Student</th>
                <th scope="col">Club</th>
                <th scope="col">Requested</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
                <th scope="col">Decision</th>
              </tr>
            </thead>
            <tbody>
              {data.map((m) => (
                <tr key={m.membership_id}>
                  <td data-label="Student">
                    <span className="font-medium">{m.students?.name ?? "Unknown student"}</span>
                    <span className="block break-all text-xs text-navy/70">{m.students?.email}</span>
                    {m.students && (
                      <span className="mono-label block">
                        {m.students.department} · Sem {m.students.semester}
                      </span>
                    )}
                  </td>
                  <td data-label="Club">{m.clubs?.club_name ?? "—"}</td>
                  <td data-label="Requested">{formatDate(m.join_date)}</td>
                  <td data-label="Role">
                    {m.status === "Active" ? (
                      <Select
                        aria-label={`Role for ${m.students?.name ?? "student"}`}
                        className="h-9 w-32"
                        value={m.role_in_club}
                        disabled={busyId === m.membership_id}
                        onChange={(e) => changeRole(m, e.target.value)}
                      >
                        <option value="Member">Member</option>
                        <option value="Executive">Executive</option>
                      </Select>
                    ) : (
                      m.role_in_club
                    )}
                  </td>
                  <td data-label="Status">
                    <Stamp status={m.status} />
                  </td>
                  <td data-label="Decision">
                    <div className="flex flex-wrap gap-2">
                      {m.status !== "Active" && (
                        <Button variant="success" size="sm" loading={busyId === m.membership_id} onClick={() => decide(m, "Active")}>
                          Approve
                        </Button>
                      )}
                      {m.status === "Pending" && (
                        <Button variant="dangerOutline" size="sm" disabled={busyId === m.membership_id} onClick={() => decide(m, "Rejected")}>
                          Reject
                        </Button>
                      )}
                      {m.status === "Active" && <span className="text-xs text-navy/70">—</span>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
