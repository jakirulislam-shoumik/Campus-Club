import { useState } from "react";
import { Search, GraduationCap } from "lucide-react";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { formatDate, shortId } from "@/lib/utils";
import type { Student } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Students() {
  const [query, setQuery] = useState("");
  const { data, loading, error, reload } = useQuery(() =>
    unwrap<Student[]>(supabase.from("students").select("*").order("name")),
  );

  const q = query.trim().toLowerCase();
  const rows = (data ?? []).filter(
    (s) =>
      !q ||
      [s.name, s.email, s.phone, s.department, s.student_id].some((v) => v.toLowerCase().includes(q)),
  );

  return (
    <>
      <PageHeader eyebrow="Administration" title="Students" description="Everyone who has registered. Search by name, email, phone, department or ID." />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load students."} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState icon={GraduationCap} title="No students yet">
          Students appear here after they register on the sign-up page. Share the registration link to get started.
        </EmptyState>
      ) : (
        <>
          <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div className="w-full max-w-sm">
              <label htmlFor="student-search" className="mb-1.5 block text-sm font-medium">
                Search students
              </label>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-navy/50" aria-hidden="true" />
                <Input
                  id="student-search"
                  type="search"
                  className="pl-9"
                  placeholder="Name, email, department…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
            </div>
            <p className="mono-label" aria-live="polite">
              Showing {rows.length} of {data.length}
            </p>
          </div>

          {rows.length === 0 ? (
            <EmptyState
              icon={Search}
              title="No students match your search"
              action={
                <Button variant="outline" onClick={() => setQuery("")}>
                  Clear search
                </Button>
              }
            >
              Check the spelling, or try a shorter search such as just a first name.
            </EmptyState>
          ) : (
            <div className="table-wrap">
              <table className="ledger-table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Department</th>
                    <th scope="col">Semester</th>
                    <th scope="col">Registered</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((s) => (
                    <tr key={s.student_id}>
                      <td data-label="ID" className="font-mono text-xs">
                        {shortId(s.student_id)}
                      </td>
                      <td data-label="Name" className="font-medium">
                        {s.name}
                      </td>
                      <td data-label="Email" className="break-all">
                        {s.email}
                      </td>
                      <td data-label="Phone">{s.phone}</td>
                      <td data-label="Department">{s.department}</td>
                      <td data-label="Semester" className="font-mono">
                        {s.semester}
                      </td>
                      <td data-label="Registered">{formatDate(s.registration_date)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
