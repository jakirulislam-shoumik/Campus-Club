import { useState } from "react";
import { CalendarDays, Plus } from "lucide-react";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { formatDate, formatTime } from "@/lib/utils";
import type { Club, ClubEvent, EventAdminRow } from "@/lib/types";
import { EventFormDialog } from "@/components/admin/EventFormDialog";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";

export default function AdminEvents() {
  const [editing, setEditing] = useState<ClubEvent | null>(null);
  const [formOpen, setFormOpen] = useState(false);

  const { data, loading, error, reload } = useQuery(async () => {
    const [events, clubs] = await Promise.all([
      unwrap<EventAdminRow[]>(
        supabase
          .from("events")
          .select("*, clubs(club_name), event_registrations(status)")
          .order("event_date", { ascending: false })
          .order("start_time"),
      ),
      unwrap<Pick<Club, "club_id" | "club_name" | "status">[]>(
        supabase.from("clubs").select("club_id, club_name, status").order("club_name"),
      ),
    ]);
    return { events, clubs };
  });

  function openForm(ev: ClubEvent | null) {
    setEditing(ev);
    setFormOpen(true);
  }

  const hasActiveClub = data?.clubs.some((c) => c.status === "Active") ?? false;

  return (
    <>
      <PageHeader
        eyebrow="Administration"
        title="Events"
        description="Create and edit events for each club. Counts exclude cancelled registrations."
        action={
          <Button variant="brass" onClick={() => openForm(null)} disabled={!hasActiveClub}>
            <Plus className="h-4 w-4" aria-hidden="true" />
            New event
          </Button>
        }
      />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load events."} onRetry={reload} />
      ) : data.events.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No events yet"
          action={
            hasActiveClub ? (
              <Button variant="brass" onClick={() => openForm(null)}>
                New event
              </Button>
            ) : undefined
          }
        >
          {hasActiveClub ? "Create the first event so students can register." : "Events belong to a club. Create or activate a club on the Clubs tab first."}
        </EmptyState>
      ) : (
        <div className="table-wrap">
          <table className="ledger-table">
            <thead>
              <tr>
                <th scope="col">Event</th>
                <th scope="col">Club</th>
                <th scope="col">When</th>
                <th scope="col">Venue</th>
                <th scope="col">Registrations</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.events.map((ev) => (
                <tr key={ev.event_id}>
                  <td data-label="Event" className="font-medium">
                    {ev.event_name}
                  </td>
                  <td data-label="Club">{ev.clubs?.club_name ?? "—"}</td>
                  <td data-label="When">
                    {formatDate(ev.event_date)}
                    <span className="block text-xs text-navy/70">
                      {formatTime(ev.start_time)} – {formatTime(ev.end_time)}
                    </span>
                  </td>
                  <td data-label="Venue">{ev.venue}</td>
                  <td data-label="Registrations" className="font-mono">
                    {ev.event_registrations.filter((r) => r.status !== "Cancelled").length}
                  </td>
                  <td data-label="Actions">
                    <Button variant="outline" size="sm" onClick={() => openForm(ev)}>
                      Edit
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <EventFormDialog
        open={formOpen}
        event={editing}
        clubs={data?.clubs ?? []}
        onClose={() => setFormOpen(false)}
        onSaved={() => {
          setFormOpen(false);
          reload();
        }}
      />
    </>
  );
}
