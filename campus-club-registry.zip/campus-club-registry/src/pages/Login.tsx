import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { errorMessage } from "@/lib/utils";
import { loginSchema } from "@/lib/schemas";
import { useForm } from "@/hooks/useForm";
import { AuthShell } from "@/components/layout/AuthShell";
import { Button } from "@/components/ui/button";
import { Field, FormError, fieldProps } from "@/components/ui/field";
import { Input } from "@/components/ui/input";

export default function Login() {
  const form = useForm({ email: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const data = form.check(loginSchema);
    if (!data) return;
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: data.email, password: data.password });
    setBusy(false);
    if (error) {
      setFormError(errorMessage(error));
      return;
    }
    toast.success("Signed in");
  }

  const { values, errors, set } = form;

  return (
    <AuthShell title="Sign in" subtitle="Use the email and password you registered with.">
      <form onSubmit={onSubmit} noValidate className="space-y-4">
        <FormError message={formError} />
        <Field id="email" label="Email" error={errors.email}>
          <Input {...fieldProps("email", errors.email)} type="email" autoComplete="email" value={values.email} onChange={set("email")} />
        </Field>
        <Field id="password" label="Password" error={errors.password}>
          <Input
            {...fieldProps("password", errors.password)}
            type="password"
            autoComplete="current-password"
            value={values.password}
            onChange={set("password")}
          />
        </Field>
        <Button type="submit" className="w-full" loading={busy}>
          Sign in
        </Button>
      </form>
      <p className="mt-5 text-center text-sm text-navy/70">
        New student?{" "}
        <Link to="/register" className="font-medium text-brass-dark underline underline-offset-2">
          Create an account
        </Link>
      </p>
    </AuthShell>
  );
}
