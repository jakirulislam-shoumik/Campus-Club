-- =====================================================================
-- Seed data: 1 admin, 3 clubs, 3 upcoming events.
-- Safe to re-run.
--
-- BEFORE running: create the admin login in the Supabase dashboard
--   Authentication > Users > Add user > Create new user
--   Email: admin@campus.edu   Password: (choose one)   Auto Confirm User: on
-- See README "Admin account" for details. If the user does not exist yet, the
-- clubs and events are still created and the admin steps are skipped.
-- =====================================================================

do $$
declare
  v_admin uuid;
begin
  select id into v_admin from auth.users where email = 'admin@campus.edu';

  if v_admin is null then
    raise notice 'admin@campus.edu not found in auth.users: create it in the dashboard, then re-run this file.';
  else
    insert into public.admins (admin_id, name, email, phone, role)
    values (v_admin, 'Registry Admin', 'admin@campus.edu', null, 'Super Admin')
    on conflict (admin_id) do nothing;

    insert into public.user_roles (user_id, role)
    values (v_admin, 'admin')
    on conflict do nothing;

    -- An admin is not also a student.
    delete from public.user_roles where user_id = v_admin and role = 'student';
    delete from public.students   where student_id = v_admin;
  end if;

  insert into public.clubs (club_name, description, category, email, established_date, status, created_by)
  values
    ('Photography Society',
     'Weekly photo walks, editing workshops and an annual campus exhibition for beginners and enthusiasts alike.',
     'Arts', 'photography@campus.edu', date '2016-09-01', 'Active', v_admin),
    ('Competitive Programming Club',
     'Practice contests, problem-solving sessions and team preparation for ICPC-style programming competitions.',
     'Technology', 'cp@campus.edu', date '2018-02-15', 'Active', v_admin),
    ('Debate Union',
     'Parliamentary and British-style debate training, inter-department tournaments and public speaking practice.',
     'Academic', 'debate@campus.edu', date '2012-08-20', 'Active', v_admin)
  on conflict (club_name) do update
    set created_by = coalesce(public.clubs.created_by, excluded.created_by);

  -- Events are dated relative to today so they are always upcoming.
  insert into public.events (club_id, event_name, description, event_date, start_time, end_time, venue, created_by)
  select c.club_id, e.event_name, e.description, current_date + e.days_ahead, e.start_time, e.end_time, e.venue, v_admin
  from (values
    ('Photography Society',
     'Golden Hour Photo Walk',
     'A guided walk around campus at golden hour with tips on light, framing and composition. Bring any camera, phones welcome.',
     10, time '16:00', time '18:30', 'Central Lawn'),
    ('Competitive Programming Club',
     'Beginner Programming Contest',
     'A friendly three-hour contest with problems for every level, followed by an editorial walkthrough.',
     17, time '14:00', time '17:00', 'Computer Lab 2, Science Block'),
    ('Debate Union',
     'Open House Debate Night',
     'Watch a showcase debate, then join a short practice round. No experience needed.',
     24, time '18:00', time '20:00', 'Auditorium B')
  ) as e(club_name, event_name, description, days_ahead, start_time, end_time, venue)
  join public.clubs c on c.club_name = e.club_name
  where not exists (
    select 1 from public.events x
    where x.club_id = c.club_id and x.event_name = e.event_name
  );
end $$;
