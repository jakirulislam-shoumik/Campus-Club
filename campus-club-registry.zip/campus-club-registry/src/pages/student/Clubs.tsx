import { useState } from "react";
import { Link } from "react-router-dom";
import { Users } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, formatDate } from "@/lib/utils";
import type { Club, Membership } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Stamp } from "@/components/ui/stamp";

export default function StudentClubs() {
  const { user } = useAuth();
  const uid = user!.id;
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, loading, error, reload } = useQuery(async () => {
    const [clubs, memberships] = await Promise.all([
      unwrap<Club[]>(supabase.from("clubs").select("*").eq("status", "Active").order("club_name")),
      unwrap<Membership[]>(supabase.from("memberships").select("*").eq("student_id", uid)),
    ]);
    return { clubs, memberships };
  }, [uid]);

  async function requestJoin(club: Club) {
    setBusyId(club.club_id);
    try {
      await unwrap(supabase.from("memberships").insert({ student_id: uid, club_id: club.club_id }));
      toast.success(`Requested to join ${club.club_name}`);
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Directory" title="Clubs" description="Browse active clubs and request to join. An administrator reviews each request." />
      {loading ? (
        <LoadingBlock label="Loading clubs…" />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load clubs."} onRetry={reload} />
      ) : data.clubs.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No active clubs yet"
          action={
            <Button asChild variant="outline">
              <Link to="/events">See upcoming events</Link>
            </Button>
          }
        >
          Clubs will appear here once an administrator activates them. Check upcoming events in the meantime.
        </EmptyState>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.clubs.map((club) => {
            const membership = data.memberships.find((m) => m.club_id === club.club_id);
            return (
              <li key={club.club_id}>
                <Card className="flex h-full flex-col p-5">
                  <p className="mono-label">{club.category}</p>
                  <h2 className="mt-1 text-lg">{club.club_name}</h2>
                  <p className="mt-2 flex-1 text-sm text-navy/80">{club.description}</p>
                  <dl className="mt-4 grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <dt className="mono-label">Established</dt>
                      <dd className="mt-0.5">{formatDate(club.established_date)}</dd>
                    </div>
                    <div className="min-w-0">
                      <dt className="mono-label">Contact</dt>
                      <dd className="mt-0.5 truncate" title={club.email}>
                        {club.email}
                      </dd>
                    </div>
                  </dl>
                  <div className="mt-4 flex min-h-[3.5rem] items-center justify-between gap-3 border-t border-navy/10 pt-4">
                    {membership ? (
                      <>
                        <span className="mono-label">Your request</span>
                        <Stamp status={membership.status} />
                      </>
                    ) : (
                      <Button loading={busyId === club.club_id} onClick={() => requestJoin(club)}>
                        Request to join
                      </Button>
                    )}
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
