import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Today as YYYY-MM-DD in the viewer's local time zone. */
export function todayISO(): string {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

/** Format a `date` column (YYYY-MM-DD) or a timestamptz string. */
export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(value);
  const d = dateOnly
    ? new Date(Number(value.slice(0, 4)), Number(value.slice(5, 7)) - 1, Number(value.slice(8, 10)))
    : new Date(value);
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

/** Format a `time` column (HH:MM:SS) as HH:MM. */
export function formatTime(value: string | null | undefined): string {
  return value ? value.slice(0, 5) : "—";
}

/** Short, ledger-style reference built from a uuid. */
export function shortId(id: string): string {
  return id.slice(0, 8).toUpperCase();
}

type PgLikeError = { code?: string; message?: string };

/** Turn a thrown Supabase / network error into a message a person can act on. */
export function errorMessage(err: unknown): string {
  const e = (err ?? {}) as PgLikeError;
  const msg = e.message ?? "";
  if (/invalid login credentials/i.test(msg))
    return "Email or password is incorrect. Check both and try again, or register if you're new.";
  if (/already registered/i.test(msg)) return "An account with this email already exists. Sign in instead.";
  if (/email not confirmed/i.test(msg)) return "Confirm your email first: open the link we sent, then sign in.";
  if (/clubs_club_name_key/.test(msg)) return "A club with that name already exists. Choose a different name.";
  if (/clubs_email_key/.test(msg)) return "Another club already uses that email. Enter a different contact email.";
  if (/memberships_student_id_club_id_key/.test(msg)) return "You have already requested to join this club.";
  if (/event_registrations_student_id_event_id_key/.test(msg)) return "You are already registered for this event.";
  if (/row-level security/i.test(msg))
    return "That action isn't allowed. The club may be inactive, or your session may have expired. Refresh and try again.";
  if (e.code === "42501") return "You don't have permission to do that. Sign in again or ask an admin.";
  if (e.code === "23505") return "That entry already exists. Check for duplicates and try again.";
  if (e.code === "23503") return "That item is linked to other records, so it can't be changed this way.";
  if (e.message && /failed to fetch|networkerror/i.test(e.message))
    return "Can't reach the server. Check your internet connection and try again.";
  return e.message || "Something went wrong. Please try again.";
}
