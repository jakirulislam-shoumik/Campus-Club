/**
 * Await a Supabase query and return its data, throwing the error otherwise.
 * Callers convert thrown errors into readable text with `errorMessage()`.
 */
export async function unwrap<T = unknown>(
  query: PromiseLike<{ data: unknown; error: { code?: string; message: string } | null }>,
): Promise<T> {
  const { data, error } = await query;
  if (error) throw error;
  return data as T;
}
