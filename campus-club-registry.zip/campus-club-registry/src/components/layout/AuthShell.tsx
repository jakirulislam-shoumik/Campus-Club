import type { ReactNode } from "react";

/** Shared frame for /login and /register. */
export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="border-b-4 border-brass bg-navy px-4 py-4 text-white">
        <div className="mx-auto max-w-6xl">
          <p className="font-heading text-xl font-bold">Campus Club Registry</p>
          <p className="mono-label text-brass-light">Clubs · Memberships · Events</p>
        </div>
      </header>
      <main className="mx-auto max-w-xl px-4 py-8 sm:py-12">
        <div className="ledger-card p-5 sm:p-8">
          <h1 className="text-2xl sm:text-3xl">{title}</h1>
          <p className="mt-1 text-sm text-navy/70">{subtitle}</p>
          <div className="mt-6">{children}</div>
        </div>
      </main>
    </div>
  );
}
