export type ClubStatus = "Active" | "Inactive";
export type MembershipStatus = "Pending" | "Active" | "Rejected";
export type RegistrationStatus = "Registered" | "Cancelled" | "Attended";

export interface Student {
  student_id: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  semester: number;
  registration_date: string;
}

export interface Club {
  club_id: string;
  club_name: string;
  description: string;
  category: string;
  email: string;
  established_date: string;
  status: ClubStatus;
  created_by: string | null;
}

export interface Membership {
  membership_id: string;
  student_id: string;
  club_id: string;
  join_date: string;
  status: MembershipStatus;
  role_in_club: "Member" | "Executive";
}

export interface ClubEvent {
  event_id: string;
  club_id: string;
  event_name: string;
  description: string;
  event_date: string;
  start_time: string;
  end_time: string;
  venue: string;
  created_by: string | null;
}

export interface EventRegistration {
  registration_id: string;
  student_id: string;
  event_id: string;
  registration_date: string;
  status: RegistrationStatus;
  feedback: string | null;
}

// Rows with embedded relations, as returned by PostgREST joins.
export type EventWithClub = ClubEvent & { clubs: Pick<Club, "club_name" | "status"> | null };
export type MembershipWithClub = Membership & { clubs: Pick<Club, "club_name" | "category"> | null };
export type MembershipWithRefs = Membership & {
  students: Pick<Student, "name" | "email" | "department" | "semester"> | null;
  clubs: Pick<Club, "club_name"> | null;
};
export type RegistrationWithEvent = EventRegistration & {
  events:
    | (Pick<ClubEvent, "event_name" | "event_date" | "start_time" | "end_time" | "venue"> & {
        clubs: Pick<Club, "club_name"> | null;
      })
    | null;
};
export type ClubWithCounts = Club & { memberships: Pick<Membership, "status">[] };
export type EventAdminRow = ClubEvent & {
  clubs: Pick<Club, "club_name"> | null;
  event_registrations: Pick<EventRegistration, "status">[];
};
export type RegistrationAdminRow = EventRegistration & {
  students: Pick<Student, "name" | "email"> | null;
  events: Pick<ClubEvent, "event_name" | "event_date"> | null;
};
