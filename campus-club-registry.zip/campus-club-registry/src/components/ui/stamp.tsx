import { cn } from "@/lib/utils";

export type StampStatus = "Active" | "Inactive" | "Pending" | "Rejected" | "Registered" | "Cancelled" | "Attended";

const COLOR: Record<StampStatus, string> = {
  Active: "text-ok",
  Attended: "text-ok",
  Registered: "text-navy",
  Pending: "text-warn",
  Rejected: "text-bad",
  Cancelled: "text-bad",
  Inactive: "text-slate-600",
};

// Slightly different tilts so a column of stamps looks hand-pressed, not mechanical.
const TILT: Record<StampStatus, string> = {
  Active: "-rotate-3",
  Attended: "rotate-2",
  Registered: "-rotate-2",
  Pending: "rotate-3",
  Rejected: "-rotate-3",
  Cancelled: "rotate-2",
  Inactive: "-rotate-2",
};

/** Rubber-stamp style status badge. */
export function Stamp({ status, className }: { status: StampStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-block select-none whitespace-nowrap rounded-[3px] border-2 border-current bg-white px-2 py-0.5 font-mono text-[11px] font-semibold uppercase tracking-[0.14em] shadow-[inset_0_0_0_1px_#fff,inset_0_0_0_2px_currentColor]",
        COLOR[status],
        TILT[status],
        className,
      )}
    >
      {status}
    </span>
  );
}
