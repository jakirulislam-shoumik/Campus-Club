import { Loader2 } from "lucide-react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

export const homeFor = (isAdmin: boolean) => (isAdmin ? "/admin/clubs" : "/clubs");

function Splash() {
  return (
    <div role="status" className="grid min-h-screen place-items-center text-navy/70">
      <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
      <span className="sr-only">Loading…</span>
    </div>
  );
}

function NoAccess() {
  const { signOut } = useAuth();
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="ledger-card max-w-md p-6 text-center">
        <h1 className="text-xl">Your account isn't set up yet</h1>
        <p className="mt-2 text-sm text-navy/70">
          You're signed in, but no role has been assigned to this account. Ask a registry administrator to assign one, or
          register a new student account.
        </p>
        <Button className="mt-5" onClick={() => void signOut()}>
          Sign out
        </Button>
      </div>
    </div>
  );
}

/** Route-protects a section: signed in, has a role, and the right one (admins are never shown student pages). */
export function RequireRole({ role }: { role: "admin" | "student" }) {
  const { user, roles, isAdmin, loading } = useAuth();
  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles.length === 0) return <NoAccess />;
  if (role === "admin" && !isAdmin) return <Navigate to="/clubs" replace />;
  if (role === "student" && isAdmin) return <Navigate to="/admin/clubs" replace />;
  return <Outlet />;
}

/** Login / register: signed-in users are sent to their own area. */
export function PublicOnly() {
  const { user, roles, isAdmin, loading } = useAuth();
  if (loading) return <Splash />;
  if (user && roles.length > 0) return <Navigate to={homeFor(isAdmin)} replace />;
  return <Outlet />;
}

export function RoleHome() {
  const { user, roles, isAdmin, loading } = useAuth();
  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles.length === 0) return <NoAccess />;
  return <Navigate to={homeFor(isAdmin)} replace />;
}
