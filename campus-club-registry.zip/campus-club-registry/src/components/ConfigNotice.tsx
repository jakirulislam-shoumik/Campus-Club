/** Shown instead of the app when the Supabase env vars are missing. */
export function ConfigNotice() {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="ledger-card max-w-lg p-6">
        <p className="mono-label text-brass-dark">Setup needed</p>
        <h1 className="mt-1 text-2xl">Connect Supabase to continue</h1>
        <p className="mt-2 text-sm text-navy/80">
          Copy <code className="font-mono text-xs">.env.example</code> to <code className="font-mono text-xs">.env</code> and
          set these two values from your Supabase project (Project Settings → API), then restart the dev server:
        </p>
        <pre className="mt-3 overflow-x-auto rounded-md bg-navy p-3 font-mono text-xs text-white">
          {"VITE_SUPABASE_URL\nVITE_SUPABASE_PUBLISHABLE_KEY"}
        </pre>
        <p className="mt-3 text-sm text-navy/70">On Vercel or Netlify, add them under the project's environment variables and redeploy.</p>
      </div>
    </div>
  );
}
