import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { ClipboardList } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@/hooks/useQuery";
import { useForm } from "@/hooks/useForm";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, formatDate, formatTime, todayISO } from "@/lib/utils";
import { feedbackSchema } from "@/lib/schemas";
import type { RegistrationWithEvent } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field, FormError, fieldProps } from "@/components/ui/field";
import { Stamp } from "@/components/ui/stamp";
import { Textarea } from "@/components/ui/input";

function FeedbackForm({ reg, onDone }: { reg: RegistrationWithEvent; onDone: () => void }) {
  const form = useForm({ feedback: reg.feedback ?? "" });
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const data = form.check(feedbackSchema);
    if (!data) return;
    setBusy(true);
    try {
      await unwrap(supabase.from("event_registrations").update({ feedback: data.feedback }).eq("registration_id", reg.registration_id));
      toast.success("Feedback saved");
      onDone();
    } catch (err) {
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <FormError message={formError} />
      <Field id="feedback" label="Your feedback" error={form.errors.feedback} hint="What worked well, and what could be better? Up to 1000 characters.">
        <Textarea
          {...fieldProps("feedback", form.errors.feedback, "hint")}
          rows={5}
          value={form.values.feedback}
          onChange={form.set("feedback")}
        />
      </Field>
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onDone}>
          Not now
        </Button>
        <Button type="submit" loading={busy}>
          Save feedback
        </Button>
      </div>
    </form>
  );
}

export default function MyRegistrations() {
  const { user } = useAuth();
  const uid = user!.id;
  const [busyId, setBusyId] = useState<string | null>(null);
  const [feedbackFor, setFeedbackFor] = useState<RegistrationWithEvent | null>(null);

  const { data, loading, error, reload } = useQuery(
    () =>
      unwrap<RegistrationWithEvent[]>(
        supabase
          .from("event_registrations")
          .select("*, events(event_name, event_date, start_time, end_time, venue, clubs(club_name))")
          .eq("student_id", uid)
          .order("registration_date", { ascending: false }),
      ),
    [uid],
  );

  async function cancel(reg: RegistrationWithEvent) {
    setBusyId(reg.registration_id);
    try {
      await unwrap(supabase.from("event_registrations").update({ status: "Cancelled" }).eq("registration_id", reg.registration_id));
      toast.success("Cancelled");
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  const today = todayISO();

  return (
    <>
      <PageHeader eyebrow="Ledger" title="My Registrations" description="Events you have registered for. Cancel before the event, and leave feedback once you're marked as attended." />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load your registrations."} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState
          icon={ClipboardList}
          title="No registrations yet"
          action={
            <Button asChild>
              <Link to="/events">Browse events</Link>
            </Button>
          }
        >
          Browse events to register for one.
        </EmptyState>
      ) : (
        <div className="table-wrap">
          <table className="ledger-table">
            <thead>
              <tr>
                <th scope="col">Event</th>
                <th scope="col">When</th>
                <th scope="col">Registered</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.map((r) => {
                const upcoming = !!r.events && r.events.event_date >= today;
                return (
                  <tr key={r.registration_id}>
                    <td data-label="Event">
                      <span className="font-medium">{r.events?.event_name ?? "Event"}</span>
                      <span className="mono-label block">{r.events?.clubs?.club_name ?? "Inactive club"}</span>
                    </td>
                    <td data-label="When">
                      {r.events ? (
                        <>
                          {formatDate(r.events.event_date)}
                          <span className="block text-xs text-navy/70">
                            {formatTime(r.events.start_time)} – {formatTime(r.events.end_time)} · {r.events.venue}
                          </span>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td data-label="Registered">{formatDate(r.registration_date)}</td>
                    <td data-label="Status">
                      <Stamp status={r.status} />
                    </td>
                    <td data-label="Action">
                      {r.status === "Registered" && upcoming && (
                        <Button variant="dangerOutline" size="sm" loading={busyId === r.registration_id} onClick={() => cancel(r)}>
                          Cancel
                        </Button>
                      )}
                      {r.status === "Registered" && !upcoming && <span className="text-xs text-navy/70">Awaiting attendance</span>}
                      {r.status === "Attended" && (
                        <div className="space-y-1.5">
                          {r.feedback && <p className="max-w-xs text-xs text-navy/80">“{r.feedback}”</p>}
                          <Button variant="outline" size="sm" onClick={() => setFeedbackFor(r)}>
                            {r.feedback ? "Edit feedback" : "Leave feedback"}
                          </Button>
                        </div>
                      )}
                      {r.status === "Cancelled" && <span className="text-xs text-navy/70">—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Dialog
        open={feedbackFor !== null}
        onClose={() => setFeedbackFor(null)}
        title="Event feedback"
        description={feedbackFor?.events?.event_name}
      >
        {feedbackFor && (
          <FeedbackForm
            reg={feedbackFor}
            onDone={() => {
              setFeedbackFor(null);
              reload();
            }}
          />
        )}
      </Dialog>
    </>
  );
}
