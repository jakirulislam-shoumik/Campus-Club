import { Link } from "react-router-dom";
import { IdCard } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { formatDate } from "@/lib/utils";
import type { MembershipWithClub } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Stamp } from "@/components/ui/stamp";

export default function MyMemberships() {
  const { user } = useAuth();
  const uid = user!.id;

  const { data, loading, error, reload } = useQuery(
    () =>
      unwrap<MembershipWithClub[]>(
        supabase
          .from("memberships")
          .select("*, clubs(club_name, category)")
          .eq("student_id", uid)
          .order("join_date", { ascending: false }),
      ),
    [uid],
  );

  return (
    <>
      <PageHeader eyebrow="Ledger" title="My Memberships" description="Every club you have asked to join, and where each request stands." />
      {loading ? (
        <LoadingBlock />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load your memberships."} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState
          icon={IdCard}
          title="No memberships yet"
          action={
            <Button asChild>
              <Link to="/clubs">Browse clubs</Link>
            </Button>
          }
        >
          Browse clubs to request one.
        </EmptyState>
      ) : (
        <div className="table-wrap">
          <table className="ledger-table">
            <thead>
              <tr>
                <th scope="col">Club</th>
                <th scope="col">Join date</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.map((m) => (
                <tr key={m.membership_id}>
                  <td data-label="Club">
                    <span className="font-medium">{m.clubs?.club_name ?? "Inactive club"}</span>
                    {m.clubs && <span className="mono-label block">{m.clubs.category}</span>}
                  </td>
                  <td data-label="Join date">{formatDate(m.join_date)}</td>
                  <td data-label="Role">{m.role_in_club}</td>
                  <td data-label="Status">
                    <Stamp status={m.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
