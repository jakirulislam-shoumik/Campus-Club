import { useState } from "react";
import { Link } from "react-router-dom";
import { BadgeCheck, CalendarDays, Clock, MapPin } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@/hooks/useQuery";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, formatDate, formatTime, todayISO } from "@/lib/utils";
import type { EventRegistration, EventWithClub, Membership } from "@/lib/types";
import { EmptyState, ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Stamp } from "@/components/ui/stamp";

export default function StudentEvents() {
  const { user } = useAuth();
  const uid = user!.id;
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, loading, error, reload } = useQuery(async () => {
    const [events, registrations, memberships] = await Promise.all([
      unwrap<EventWithClub[]>(
        supabase
          .from("events")
          .select("*, clubs(club_name, status)")
          .gte("event_date", todayISO())
          .order("event_date")
          .order("start_time"),
      ),
      unwrap<EventRegistration[]>(supabase.from("event_registrations").select("*").eq("student_id", uid)),
      unwrap<Membership[]>(supabase.from("memberships").select("*").eq("student_id", uid).eq("status", "Active")),
    ]);
    return { events, registrations, memberships };
  }, [uid]);

  async function register(ev: EventWithClub) {
    setBusyId(ev.event_id);
    try {
      await unwrap(supabase.from("event_registrations").insert({ student_id: uid, event_id: ev.event_id }));
      toast.success(`Registered for ${ev.event_name}`);
      reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Calendar" title="Events" description="Upcoming events from all clubs, soonest first." />
      {loading ? (
        <LoadingBlock label="Loading events…" />
      ) : error || !data ? (
        <ErrorBlock message={error ?? "Couldn't load events."} onRetry={reload} />
      ) : data.events.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No upcoming events"
          action={
            <Button asChild variant="outline">
              <Link to="/clubs">Browse clubs</Link>
            </Button>
          }
        >
          Nothing is scheduled right now. Join a club to hear about new events first.
        </EmptyState>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2">
          {data.events.map((ev) => {
            const registration = data.registrations.find((r) => r.event_id === ev.event_id);
            const isMember = data.memberships.some((m) => m.club_id === ev.club_id);
            // Students can't read inactive clubs, so a missing club means registration is closed.
            const clubActive = ev.clubs?.status === "Active";
            return (
              <li key={ev.event_id}>
                <Card className="flex h-full flex-col p-5">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <p className="mono-label text-brass-dark">{formatDate(ev.event_date)}</p>
                    {isMember && (
                      <span className="inline-flex items-center gap-1 rounded-full border border-brass bg-brass/10 px-2 py-0.5 text-xs font-medium text-brass-dark">
                        <BadgeCheck className="h-3.5 w-3.5" aria-hidden="true" />
                        Active member
                      </span>
                    )}
                  </div>
                  <h2 className="mt-1 text-lg">{ev.event_name}</h2>
                  <p className="text-sm font-medium text-navy/80">{ev.clubs?.club_name ?? "Inactive club"}</p>
                  <p className="mt-2 flex-1 text-sm text-navy/80">{ev.description}</p>
                  <dl className="mt-4 space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <dt className="sr-only">Time</dt>
                      <Clock className="h-4 w-4 text-navy/60" aria-hidden="true" />
                      <dd>
                        {formatTime(ev.start_time)} – {formatTime(ev.end_time)}
                      </dd>
                    </div>
                    <div className="flex items-center gap-2">
                      <dt className="sr-only">Venue</dt>
                      <MapPin className="h-4 w-4 text-navy/60" aria-hidden="true" />
                      <dd>{ev.venue}</dd>
                    </div>
                  </dl>
                  <div className="mt-4 flex min-h-[3.5rem] items-center justify-between gap-3 border-t border-navy/10 pt-4">
                    {registration ? (
                      <>
                        <span className="mono-label">Your registration</span>
                        <Stamp status={registration.status} />
                      </>
                    ) : clubActive ? (
                      <Button loading={busyId === ev.event_id} onClick={() => register(ev)}>
                        Register
                      </Button>
                    ) : (
                      <p className="text-sm text-navy/70">Registration is closed because this club is inactive.</p>
                    )}
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
