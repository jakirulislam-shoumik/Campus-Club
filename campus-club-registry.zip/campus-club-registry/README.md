# Campus Club Registry

A club registration and membership system for a university. Students browse clubs, request membership and register for events; administrators approve requests and manage clubs, events and attendance.

**Stack:** React 18 · TypeScript · Vite · Tailwind CSS · shadcn/ui-style components · Supabase (Postgres, Auth, Row Level Security)

## Features

**Students** (self-register at `/register`)
- **Clubs**: card grid of active clubs with a *Request to join* button; once requested, the card shows the current status stamp
- **My Memberships**: club, join date, role and status
- **Events**: upcoming events sorted by date, with a *Register* button and an "Active member" badge for clubs you belong to
- **My Registrations**: cancel upcoming registrations; leave feedback once an admin marks you as attended

**Admins** (route-protected)
- **Clubs**: create, edit, activate/deactivate, with active member counts
- **Membership Requests**: pending first, Approve / Reject, pending-count badge on the tab
- **Events**: create and edit events linked to a club, with registration counts
- **Event Registrations**: all registrations, filter by event, mark *Attended*
- **Students**: searchable list

## Local setup

Prerequisites: Node.js 18+ and a free [Supabase](https://supabase.com) project.

```bash
npm install
cp .env.example .env     # then fill in the two values below
npm run dev
```

### Environment variables

| Variable | Where to find it |
| --- | --- |
| `VITE_SUPABASE_URL` | Supabase dashboard → Project Settings → API → Project URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Same page → `anon` / publishable key |

Only these two public values are used by the app. Never put a `service_role` key in a `VITE_` variable. `.env` is git-ignored.

If the variables are missing, the app shows a setup notice instead of the sign-in page.

### Database setup

Run the SQL files once, in order, in the Supabase **SQL Editor** (or with the Supabase CLI: `supabase db push`, then run the seed file):

1. `supabase/migrations/20261121000000_init.sql`: tables, indexes, `has_role()`, triggers and all RLS policies
2. `supabase/seed.sql`: 3 clubs, 3 upcoming events and the admin role assignment (safe to re-run)

### Admin account

Passwords are managed by Supabase Auth, never stored in app tables, so the seed cannot set one. To create `admin@campus.edu`:

1. In the dashboard open **Authentication → Users → Add user → Create new user**.
2. Enter `admin@campus.edu`, choose a password, and tick **Auto Confirm User**.
3. Run `supabase/seed.sql` (again, if you already ran it). It finds that user and inserts a row in `admins` and a row in `user_roles` with the `admin` role.
4. Sign in at `/login` with that email and password.

To change the password later: **Authentication → Users →** the user's `…` menu → **Send password recovery**, or set a new one from the user's details panel.

To make someone else an admin, create their auth user, then insert into `public.admins` and `public.user_roles` (`role = 'admin'`), the same way the seed does.

### Supabase Auth settings

- **Email confirmation** (Authentication → Providers → Email): if it is on, new students must click the emailed link before signing in, and the app tells them so. Turn it off for faster local testing.
- **Site URL / Redirect URLs** (Authentication → URL Configuration): add your deployed URL once you have one.

## How access control works

- Roles live only in `user_roles` (`admin` | `student`). There is no role column on the profile tables.
- `has_role(user_id, role)` is `SECURITY DEFINER`, so policies can check roles without recursing into `user_roles`' own RLS.
- A trigger on `auth.users` creates the `students` row and the `student` role when someone signs up; profile fields travel as signup metadata.
- **Students** can read active clubs (plus clubs they belong to) and all events, and read/write only their own profile, memberships and registrations. Membership inserts must be `Pending` / `Member` for an `Active` club. Registration inserts require an `Active` club, and `UNIQUE (student_id, event_id)` blocks duplicates. A guard trigger limits students to cancelling a registration (for events that have not passed) and writing feedback after it is marked `Attended`.
- **Admins** can read and write everything.
- The `anon` role has no table access at all.

The UI hides admin pages from students, but the database enforces the rules; the client is never trusted.

## Project structure

```
src/
  components/      ui/ (button, input, dialog, stamp…), layout/, admin/ form dialogs
  hooks/           useAuth (session + roles), useQuery, useForm
  lib/             supabase client, zod schemas, types, helpers
  pages/           Login, Register, student/, admin/
supabase/
  migrations/      schema + RLS
  seed.sql         clubs, events, admin role assignment
```

## Deploying from GitHub

The repo includes SPA fallback routing for both hosts (`vercel.json`, `netlify.toml` and `public/_redirects`), so deep links like `/admin/clubs` work on refresh.

1. Push this project to a GitHub repository.
2. **Vercel:** *Add New → Project*, import the repo. Framework preset: Vite (build `npm run build`, output `dist`).
   **Netlify:** *Add new site → Import from Git*. Build command `npm run build`, publish directory `dist` (already set in `netlify.toml`).
3. Add the environment variables `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` in the host's project settings.
4. Deploy, then add the deployed URL to Supabase **Authentication → URL Configuration**.

Vite inlines `VITE_` variables at build time, so redeploy after changing them.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the dev server |
| `npm run build` | Typecheck and build to `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run typecheck` | TypeScript check only |

## Design notes

Navy `#14213d`, brass `#a9852e`, paper `#eef1f6`. Fraunces for headings, Inter for body, JetBrains Mono for IDs and labels. Cards carry a thin brass left edge; statuses are tilted rubber-stamp badges. Tables stack into labelled cards on small screens, and keyboard focus is always visible.
