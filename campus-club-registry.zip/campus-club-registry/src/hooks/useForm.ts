import { useState, type ChangeEvent } from "react";
import type { z } from "zod";
import { validate, type FieldErrors } from "@/lib/schemas";

type Control = HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;

/** Tiny controlled-form helper: values, per-field errors, and zod validation with focus on the first error. */
export function useForm<T extends Record<string, string>>(initial: T) {
  const [values, setValues] = useState<T>(initial);
  const [errors, setErrors] = useState<FieldErrors>({});

  const set = (key: keyof T & string) => (e: ChangeEvent<Control>) => {
    const value = e.target.value;
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((prev) => {
      if (!prev[key]) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  /** Returns parsed data, or null after showing errors and focusing the first invalid field. */
  function check<D>(schema: z.ZodType<D, z.ZodTypeDef, unknown>): D | null {
    const result = validate(schema, values);
    if (result.ok) {
      setErrors({});
      return result.data;
    }
    setErrors(result.errors);
    const first = Object.keys(result.errors)[0];
    requestAnimationFrame(() => document.getElementById(first)?.focus());
    return null;
  }

  return { values, errors, set, check };
}
