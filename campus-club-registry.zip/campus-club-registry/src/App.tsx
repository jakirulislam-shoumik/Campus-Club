import { Link, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { supabaseConfigured } from "@/lib/supabase";
import { ConfigNotice } from "@/components/ConfigNotice";
import { AppLayout } from "@/components/layout/AppLayout";
import { PublicOnly, RequireRole, RoleHome } from "@/components/layout/RouteGuards";
import { Button } from "@/components/ui/button";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import StudentClubs from "@/pages/student/Clubs";
import MyMemberships from "@/pages/student/MyMemberships";
import StudentEvents from "@/pages/student/Events";
import MyRegistrations from "@/pages/student/MyRegistrations";
import AdminClubs from "@/pages/admin/AdminClubs";
import MembershipRequests from "@/pages/admin/MembershipRequests";
import AdminEvents from "@/pages/admin/AdminEvents";
import EventRegistrations from "@/pages/admin/EventRegistrations";
import Students from "@/pages/admin/Students";

function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="ledger-card max-w-md p-6 text-center">
        <p className="mono-label text-brass-dark">Error 404</p>
        <h1 className="mt-1 text-2xl">Page not found</h1>
        <p className="mt-2 text-sm text-navy/70">That address isn't in the registry. Check the link, or head back to your home page.</p>
        <Button asChild className="mt-5">
          <Link to="/">Go to home</Link>
        </Button>
      </div>
    </div>
  );
}

export default function App() {
  if (!supabaseConfigured) return <ConfigNotice />;

  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<RoleHome />} />

        <Route element={<PublicOnly />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>

        <Route element={<RequireRole role="student" />}>
          <Route element={<AppLayout variant="student" />}>
            <Route path="/clubs" element={<StudentClubs />} />
            <Route path="/memberships" element={<MyMemberships />} />
            <Route path="/events" element={<StudentEvents />} />
            <Route path="/registrations" element={<MyRegistrations />} />
          </Route>
        </Route>

        <Route element={<RequireRole role="admin" />}>
          <Route path="/admin" element={<AppLayout variant="admin" />}>
            <Route index element={<Navigate to="clubs" replace />} />
            <Route path="clubs" element={<AdminClubs />} />
            <Route path="requests" element={<MembershipRequests />} />
            <Route path="events" element={<AdminEvents />} />
            <Route path="registrations" element={<EventRegistrations />} />
            <Route path="students" element={<Students />} />
          </Route>
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </AuthProvider>
  );
}
