import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { errorMessage } from "@/lib/utils";
import { DEPARTMENTS, registerSchema } from "@/lib/schemas";
import { useForm } from "@/hooks/useForm";
import { AuthShell } from "@/components/layout/AuthShell";
import { Button } from "@/components/ui/button";
import { Field, FormError, fieldProps } from "@/components/ui/field";
import { Input, Select } from "@/components/ui/input";

export default function Register() {
  const navigate = useNavigate();
  const form = useForm({ name: "", email: "", phone: "", department: "", semester: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const data = form.check(registerSchema);
    if (!data) return;
    setBusy(true);
    // Profile fields travel as auth metadata; a database trigger creates the students row and 'student' role.
    const { data: res, error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: { data: { name: data.name, phone: data.phone, department: data.department, semester: data.semester } },
    });
    setBusy(false);
    if (error) {
      setFormError(errorMessage(error));
      return;
    }
    // With email confirmation on, an existing address comes back as a user with no identities.
    if (res.user && res.user.identities && res.user.identities.length === 0) {
      setFormError("An account with this email already exists. Sign in instead.");
      return;
    }
    if (!res.session) {
      toast.success("Account created. Confirm your email, then sign in.");
      navigate("/login");
      return;
    }
    toast.success("Account created");
  }

  const { values, errors, set } = form;

  return (
    <AuthShell title="Create your account" subtitle="Register as a student to join clubs and sign up for events.">
      <form onSubmit={onSubmit} noValidate className="space-y-4">
        <FormError message={formError} />
        <Field id="name" label="Full name" error={errors.name}>
          <Input {...fieldProps("name", errors.name)} autoComplete="name" value={values.name} onChange={set("name")} />
        </Field>
        <Field id="email" label="Email" error={errors.email}>
          <Input {...fieldProps("email", errors.email)} type="email" autoComplete="email" value={values.email} onChange={set("email")} />
        </Field>
        <Field id="phone" label="Phone" error={errors.phone} hint="Include the country code if you can, e.g. +880 1712 345678.">
          <Input
            {...fieldProps("phone", errors.phone, "hint")}
            type="tel"
            autoComplete="tel"
            value={values.phone}
            onChange={set("phone")}
          />
        </Field>
        <div className="grid gap-4 sm:grid-cols-[1fr_9rem]">
          <Field id="department" label="Department" error={errors.department}>
            <Input
              {...fieldProps("department", errors.department)}
              list="department-options"
              value={values.department}
              onChange={set("department")}
            />
            <datalist id="department-options">
              {DEPARTMENTS.map((d) => (
                <option key={d} value={d} />
              ))}
            </datalist>
          </Field>
          <Field id="semester" label="Semester" error={errors.semester}>
            <Select {...fieldProps("semester", errors.semester)} value={values.semester} onChange={set("semester")}>
              <option value="">Choose…</option>
              {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field id="password" label="Password" error={errors.password} hint="At least 8 characters, with a letter and a number.">
          <Input
            {...fieldProps("password", errors.password, "hint")}
            type={showPassword ? "text" : "password"}
            autoComplete="new-password"
            value={values.password}
            onChange={set("password")}
          />
        </Field>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            className="h-4 w-4 accent-[#14213d]"
            checked={showPassword}
            onChange={(e) => setShowPassword(e.target.checked)}
          />
          Show password
        </label>
        <Button type="submit" className="w-full" loading={busy}>
          Create account
        </Button>
      </form>
      <p className="mt-5 text-center text-sm text-navy/70">
        Already registered?{" "}
        <Link to="/login" className="font-medium text-brass-dark underline underline-offset-2">
          Sign in
        </Link>
      </p>
    </AuthShell>
  );
}
