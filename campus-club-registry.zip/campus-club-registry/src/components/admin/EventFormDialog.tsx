import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage, formatTime } from "@/lib/utils";
import { eventSchema } from "@/lib/schemas";
import type { Club, ClubEvent } from "@/lib/types";
import { useForm } from "@/hooks/useForm";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field, FormError, fieldProps } from "@/components/ui/field";
import { Input, Select, Textarea } from "@/components/ui/input";

type ClubOption = Pick<Club, "club_id" | "club_name" | "status">;

function EventForm({
  event,
  clubs,
  onClose,
  onSaved,
}: {
  event: ClubEvent | null;
  clubs: ClubOption[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const form = useForm({
    club_id: event?.club_id ?? "",
    event_name: event?.event_name ?? "",
    description: event?.description ?? "",
    event_date: event?.event_date ?? "",
    start_time: event ? formatTime(event.start_time) : "",
    end_time: event ? formatTime(event.end_time) : "",
    venue: event?.venue ?? "",
  });
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const { values, errors, set } = form;

  // New events can only be linked to active clubs; an existing event keeps its club even if now inactive.
  const options = clubs.filter((c) => c.status === "Active" || c.club_id === event?.club_id);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const data = form.check(eventSchema(!event));
    if (!data) return;
    setBusy(true);
    try {
      if (event) await unwrap(supabase.from("events").update(data).eq("event_id", event.event_id));
      else await unwrap(supabase.from("events").insert(data));
      toast.success(event ? "Event updated" : "Event created");
      onSaved();
    } catch (err) {
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <FormError message={formError} />
      <Field id="club_id" label="Club" error={errors.club_id}>
        <Select {...fieldProps("club_id", errors.club_id)} value={values.club_id} onChange={set("club_id")}>
          <option value="">Choose a club…</option>
          {options.map((c) => (
            <option key={c.club_id} value={c.club_id}>
              {c.club_name}
            </option>
          ))}
        </Select>
      </Field>
      <Field id="event_name" label="Event name" error={errors.event_name}>
        <Input {...fieldProps("event_name", errors.event_name)} value={values.event_name} onChange={set("event_name")} />
      </Field>
      <Field id="description" label="Description" error={errors.description}>
        <Textarea {...fieldProps("description", errors.description)} rows={3} value={values.description} onChange={set("description")} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field id="event_date" label="Date" error={errors.event_date}>
          <Input {...fieldProps("event_date", errors.event_date)} type="date" value={values.event_date} onChange={set("event_date")} />
        </Field>
        <Field id="start_time" label="Starts" error={errors.start_time}>
          <Input {...fieldProps("start_time", errors.start_time)} type="time" value={values.start_time} onChange={set("start_time")} />
        </Field>
        <Field id="end_time" label="Ends" error={errors.end_time}>
          <Input {...fieldProps("end_time", errors.end_time)} type="time" value={values.end_time} onChange={set("end_time")} />
        </Field>
      </div>
      <Field id="venue" label="Venue" error={errors.venue}>
        <Input {...fieldProps("venue", errors.venue)} value={values.venue} onChange={set("venue")} />
      </Field>
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" loading={busy}>
          {event ? "Save changes" : "Create event"}
        </Button>
      </div>
    </form>
  );
}

export function EventFormDialog({
  open,
  event,
  clubs,
  onClose,
  onSaved,
}: {
  open: boolean;
  event: ClubEvent | null;
  clubs: ClubOption[];
  onClose: () => void;
  onSaved: () => void;
}) {
  return (
    <Dialog open={open} onClose={onClose} title={event ? "Edit event" : "New event"}>
      <EventForm event={event} clubs={clubs} onClose={onClose} onSaved={onSaved} />
    </Dialog>
  );
}
