import * as React from "react";
import { cn } from "@/lib/utils";

/** White card with a thin brass left edge. */
export const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("ledger-card", className)} {...props} />
));
Card.displayName = "Card";
