-- =====================================================================
-- Campus Club Registry: schema, helper functions, triggers, RLS
-- Run once in the Supabase SQL editor (or via `supabase db push`).
-- =====================================================================

-- ---------- Types ----------------------------------------------------
create type public.app_role as enum ('admin', 'student');

-- ---------- Tables ---------------------------------------------------
create table public.students (
  student_id        uuid primary key references auth.users (id) on delete cascade,
  name              text        not null check (char_length(btrim(name)) >= 2),
  email             text        not null unique,
  phone             text        not null,
  department        text        not null,
  semester          smallint    not null check (semester between 1 and 12),
  registration_date timestamptz not null default now()
);

create table public.admins (
  admin_id uuid primary key references auth.users (id) on delete cascade,
  name     text not null,
  email    text not null unique,
  phone    text,
  role     text not null default 'Club Admin' check (role in ('Super Admin', 'Club Admin'))
);

-- Roles live here and ONLY here (never on a profile table).
create table public.user_roles (
  user_id uuid not null references auth.users (id) on delete cascade,
  role    public.app_role not null,
  primary key (user_id, role)
);

create table public.clubs (
  club_id          uuid primary key default gen_random_uuid(),
  club_name        text not null unique,
  description      text not null,
  category         text not null,
  email            text not null unique,
  established_date date not null,
  status           text not null default 'Active' check (status in ('Active', 'Inactive')),
  created_by       uuid references public.admins (admin_id) on delete set null
);

create table public.memberships (
  membership_id uuid primary key default gen_random_uuid(),
  student_id    uuid not null references public.students (student_id) on delete cascade,
  club_id       uuid not null references public.clubs (club_id) on delete cascade,
  join_date     timestamptz not null default now(),
  status        text not null default 'Pending' check (status in ('Pending', 'Active', 'Rejected')),
  role_in_club  text not null default 'Member' check (role_in_club in ('Member', 'Executive')),
  unique (student_id, club_id)
);

create table public.events (
  event_id    uuid primary key default gen_random_uuid(),
  club_id     uuid not null references public.clubs (club_id) on delete cascade,
  event_name  text not null,
  description text not null,
  event_date  date not null,
  start_time  time not null,
  end_time    time not null,
  venue       text not null,
  created_by  uuid references public.admins (admin_id) on delete set null,
  check (end_time > start_time)
);

create table public.event_registrations (
  registration_id   uuid primary key default gen_random_uuid(),
  student_id        uuid not null references public.students (student_id) on delete cascade,
  event_id          uuid not null references public.events (event_id) on delete cascade,
  registration_date timestamptz not null default now(),
  status            text not null default 'Registered' check (status in ('Registered', 'Cancelled', 'Attended')),
  feedback          text check (feedback is null or char_length(feedback) <= 1000),
  unique (student_id, event_id)
);

-- ---------- Indexes (FKs and common filters) ---------------------------
create index clubs_status_idx                 on public.clubs (status);
create index clubs_created_by_idx             on public.clubs (created_by);
create index memberships_club_id_idx          on public.memberships (club_id);
create index memberships_status_idx           on public.memberships (status);
create index events_club_id_idx               on public.events (club_id);
create index events_event_date_idx            on public.events (event_date);
create index events_created_by_idx            on public.events (created_by);
create index event_registrations_event_idx    on public.event_registrations (event_id);
create index event_registrations_status_idx   on public.event_registrations (status);

-- ---------- Helper functions ------------------------------------------
-- SECURITY DEFINER so policies can check roles without recursing into
-- user_roles' own RLS.
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

-- True when the event exists and its club is Active.
create or replace function public.event_club_is_active(_event_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.events e
    join public.clubs c on c.club_id = e.club_id
    where e.event_id = _event_id and c.status = 'Active'
  );
$$;

-- ---------- Signup trigger: students + 'student' role ------------------
-- Students self-register through supabase.auth.signUp with profile fields
-- in user metadata. Users created without a `name` (e.g. the admin account
-- created from the dashboard) get no student row.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.raw_user_meta_data ? 'name' then
    insert into public.students (student_id, name, email, phone, department, semester)
    values (
      new.id,
      btrim(new.raw_user_meta_data ->> 'name'),
      new.email,
      coalesce(new.raw_user_meta_data ->> 'phone', ''),
      coalesce(new.raw_user_meta_data ->> 'department', ''),
      coalesce(nullif(new.raw_user_meta_data ->> 'semester', '')::smallint, 1)
    );
    insert into public.user_roles (user_id, role)
    values (new.id, 'student')
    on conflict do nothing;
  end if;
  return new;
end;
$$;

revoke execute on function public.handle_new_user() from public, anon, authenticated;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Guard triggers (column-level rules RLS can't express) ------
-- Students may not change their identity columns.
create or replace function public.guard_student_update()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null or public.has_role(auth.uid(), 'admin') then
    return new;
  end if;
  new.student_id        := old.student_id;
  new.email             := old.email;
  new.registration_date := old.registration_date;
  return new;
end;
$$;

create trigger guard_student_update
  before update on public.students
  for each row execute function public.guard_student_update();

-- Students may only: Registered -> Cancelled (for events not yet past), and
-- add/edit feedback once the registration is Attended.
create or replace function public.guard_registration_update()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null or public.has_role(auth.uid(), 'admin') then
    return new;
  end if;

  if new.student_id <> old.student_id
     or new.event_id <> old.event_id
     or new.registration_date <> old.registration_date then
    raise exception 'Only the status and feedback of a registration can be changed.';
  end if;

  if new.status <> old.status then
    if not (old.status = 'Registered' and new.status = 'Cancelled') then
      raise exception 'You can only cancel a registration that is still Registered.';
    end if;
    if exists (
      select 1 from public.events e
      where e.event_id = old.event_id and e.event_date < current_date
    ) then
      raise exception 'Past events can no longer be cancelled.';
    end if;
  end if;

  if new.feedback is distinct from old.feedback and old.status <> 'Attended' then
    raise exception 'Feedback can be added after the event is marked Attended.';
  end if;

  return new;
end;
$$;

create trigger guard_registration_update
  before update on public.event_registrations
  for each row execute function public.guard_registration_update();

-- ---------- Row Level Security ----------------------------------------
alter table public.students            enable row level security;
alter table public.admins              enable row level security;
alter table public.user_roles          enable row level security;
alter table public.clubs               enable row level security;
alter table public.memberships         enable row level security;
alter table public.events              enable row level security;
alter table public.event_registrations enable row level security;

-- students
create policy "students read own profile" on public.students
  for select to authenticated
  using (student_id = (select auth.uid()));
create policy "students update own profile" on public.students
  for update to authenticated
  using (student_id = (select auth.uid()))
  with check (student_id = (select auth.uid()));
create policy "admins manage students" on public.students
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- admins
create policy "admins manage admins" on public.admins
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- user_roles (read-only for users; only admins can change roles)
create policy "users read own roles" on public.user_roles
  for select to authenticated
  using (user_id = (select auth.uid()));
create policy "admins manage roles" on public.user_roles
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- clubs: everyone signed in reads Active clubs (plus clubs they belong to, so
-- their own history still shows a name if a club is later deactivated)
create policy "read active clubs" on public.clubs
  for select to authenticated
  using (
    status = 'Active'
    or exists (
      select 1 from public.memberships m
      where m.club_id = clubs.club_id and m.student_id = (select auth.uid())
    )
  );
create policy "admins manage clubs" on public.clubs
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- memberships
create policy "students read own memberships" on public.memberships
  for select to authenticated
  using (student_id = (select auth.uid()));
create policy "students request membership" on public.memberships
  for insert to authenticated
  with check (
    student_id = (select auth.uid())
    and status = 'Pending'
    and role_in_club = 'Member'
    and exists (
      select 1 from public.clubs c
      where c.club_id = memberships.club_id and c.status = 'Active'
    )
  );
create policy "admins manage memberships" on public.memberships
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- events
create policy "read all events" on public.events
  for select to authenticated
  using (true);
create policy "admins manage events" on public.events
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- event_registrations
-- Duplicate registrations are blocked by UNIQUE (student_id, event_id).
create policy "students read own registrations" on public.event_registrations
  for select to authenticated
  using (student_id = (select auth.uid()));
create policy "students register for events of active clubs" on public.event_registrations
  for insert to authenticated
  with check (
    student_id = (select auth.uid())
    and status = 'Registered'
    and feedback is null
    and public.event_club_is_active(event_id)
  );
create policy "students update own registrations" on public.event_registrations
  for update to authenticated
  using (student_id = (select auth.uid()) and status <> 'Cancelled')
  with check (student_id = (select auth.uid()));
create policy "admins manage registrations" on public.event_registrations
  for all to authenticated
  using (public.has_role((select auth.uid()), 'admin'))
  with check (public.has_role((select auth.uid()), 'admin'));

-- ---------- Privileges -------------------------------------------------
-- Signed-out visitors get nothing; signed-in users are limited by RLS.
revoke all on all tables in schema public from anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;
grant execute on function public.event_club_is_active(uuid) to authenticated;
