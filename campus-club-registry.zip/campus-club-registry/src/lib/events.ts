/** Lets the admin tab bar refresh its pending-requests badge after a decision. */
const MEMBERSHIPS_CHANGED = "registry:memberships-changed";

export function notifyMembershipsChanged() {
  window.dispatchEvent(new Event(MEMBERSHIPS_CHANGED));
}

export function onMembershipsChanged(handler: () => void): () => void {
  window.addEventListener(MEMBERSHIPS_CHANGED, handler);
  return () => window.removeEventListener(MEMBERSHIPS_CHANGED, handler);
}
