import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { LogOut } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";
import { onMembershipsChanged } from "@/lib/events";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const STUDENT_TABS = [
  { to: "/clubs", label: "Clubs" },
  { to: "/memberships", label: "My Memberships" },
  { to: "/events", label: "Events" },
  { to: "/registrations", label: "My Registrations" },
];

const ADMIN_TABS = [
  { to: "/admin/clubs", label: "Clubs" },
  { to: "/admin/requests", label: "Membership Requests" },
  { to: "/admin/events", label: "Events" },
  { to: "/admin/registrations", label: "Event Registrations" },
  { to: "/admin/students", label: "Students" },
];

export function AppLayout({ variant }: { variant: "student" | "admin" }) {
  const { displayName, signOut } = useAuth();
  const location = useLocation();
  const [pending, setPending] = useState(0);
  const tabs = variant === "admin" ? ADMIN_TABS : STUDENT_TABS;

  // Pending-request count for the admin tab badge; refreshed on navigation and after each decision.
  useEffect(() => {
    if (variant !== "admin") return;
    let cancelled = false;
    const load = async () => {
      const { count } = await supabase
        .from("memberships")
        .select("membership_id", { count: "exact", head: true })
        .eq("status", "Pending");
      if (!cancelled) setPending(count ?? 0);
    };
    void load();
    const off = onMembershipsChanged(() => void load());
    return () => {
      cancelled = true;
      off();
    };
  }, [variant, location.pathname]);

  return (
    <div className="min-h-screen">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-white focus:px-3 focus:py-2 focus:text-navy"
      >
        Skip to content
      </a>

      <header className="border-b-4 border-brass bg-navy text-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <Link to="/" className="min-w-0 rounded-sm">
            <span className="block truncate font-heading text-lg font-bold leading-tight sm:text-xl">Campus Club Registry</span>
            <span className="mono-label hidden text-brass-light sm:block">
              {variant === "admin" ? "Administrator ledger" : "Student ledger"}
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="hidden max-w-[14rem] truncate text-sm text-white/80 sm:block" title={displayName}>
              {displayName}
            </span>
            <Button
              variant="onNavy"
              size="sm"
              onClick={async () => {
                await signOut();
                toast.success("Signed out");
              }}
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
              Sign out
            </Button>
          </div>
        </div>
      </header>

      <nav aria-label="Primary" className="border-b border-navy/10 bg-white">
        <ul className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-2 sm:px-4">
          {tabs.map((tab) => (
            <li key={tab.to} className="shrink-0">
              <NavLink
                to={tab.to}
                className={({ isActive }) =>
                  cn(
                    "inline-flex items-center border-b-[3px] px-3 py-3 text-sm font-medium transition-colors",
                    isActive ? "border-brass text-navy" : "border-transparent text-navy/65 hover:text-navy",
                  )
                }
              >
                {tab.label}
                {tab.to === "/admin/requests" && pending > 0 && (
                  <span
                    className="ml-2 inline-flex min-w-[1.25rem] items-center justify-center rounded-full bg-brass-dark px-1.5 font-mono text-[11px] font-medium text-white"
                    aria-label={`${pending} pending`}
                  >
                    {pending}
                  </span>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <main id="main" className="mx-auto max-w-6xl px-4 py-6 sm:py-8">
        <Outlet />
      </main>
    </div>
  );
}
