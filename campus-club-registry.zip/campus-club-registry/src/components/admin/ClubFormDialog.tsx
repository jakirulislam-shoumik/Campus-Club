import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/lib/supabase";
import { unwrap } from "@/lib/db";
import { errorMessage } from "@/lib/utils";
import { CATEGORIES, clubSchema } from "@/lib/schemas";
import type { Club } from "@/lib/types";
import { useForm } from "@/hooks/useForm";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field, FormError, fieldProps } from "@/components/ui/field";
import { Input, Select, Textarea } from "@/components/ui/input";

function ClubForm({ club, onClose, onSaved }: { club: Club | null; onClose: () => void; onSaved: () => void }) {
  const form = useForm({
    club_name: club?.club_name ?? "",
    description: club?.description ?? "",
    category: club?.category ?? "",
    email: club?.email ?? "",
    established_date: club?.established_date ?? "",
    status: club?.status ?? "Active",
  });
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const { values, errors, set } = form;
  const categories: string[] = [...CATEGORIES];
  if (values.category && !categories.includes(values.category)) categories.push(values.category);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const data = form.check(clubSchema);
    if (!data) return;
    const payload = { ...data, email: data.email.toLowerCase() };
    setBusy(true);
    try {
      if (club) await unwrap(supabase.from("clubs").update(payload).eq("club_id", club.club_id));
      else await unwrap(supabase.from("clubs").insert(payload));
      toast.success(club ? "Club updated" : "Club created");
      onSaved();
    } catch (err) {
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      <FormError message={formError} />
      <Field id="club_name" label="Club name" error={errors.club_name}>
        <Input {...fieldProps("club_name", errors.club_name)} value={values.club_name} onChange={set("club_name")} />
      </Field>
      <Field id="description" label="Description" error={errors.description}>
        <Textarea {...fieldProps("description", errors.description)} rows={4} value={values.description} onChange={set("description")} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="category" label="Category" error={errors.category}>
          <Select {...fieldProps("category", errors.category)} value={values.category} onChange={set("category")}>
            <option value="">Choose…</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
        </Field>
        <Field id="status" label="Status" error={errors.status}>
          <Select {...fieldProps("status", errors.status)} value={values.status} onChange={set("status")}>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </Select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="email" label="Contact email" error={errors.email}>
          <Input {...fieldProps("email", errors.email)} type="email" value={values.email} onChange={set("email")} />
        </Field>
        <Field id="established_date" label="Established" error={errors.established_date}>
          <Input
            {...fieldProps("established_date", errors.established_date)}
            type="date"
            value={values.established_date}
            onChange={set("established_date")}
          />
        </Field>
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" loading={busy}>
          {club ? "Save changes" : "Create club"}
        </Button>
      </div>
    </form>
  );
}

export function ClubFormDialog({
  open,
  club,
  onClose,
  onSaved,
}: {
  open: boolean;
  club: Club | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  return (
    <Dialog open={open} onClose={onClose} title={club ? "Edit club" : "New club"}>
      <ClubForm club={club} onClose={onClose} onSaved={onSaved} />
    </Dialog>
  );
}
