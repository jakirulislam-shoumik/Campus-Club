import { z } from "zod";
import { todayISO } from "./utils";

export const CATEGORIES = ["Arts", "Technology", "Academic", "Sports", "Culture", "Community Service", "Other"] as const;
export const DEPARTMENTS = [
  "Computer Science",
  "Electrical Engineering",
  "Business Administration",
  "Economics",
  "English",
  "Law",
  "Mathematics",
  "Physics",
  "Architecture",
];

const email = z
  .string()
  .trim()
  .min(1, "Enter an email address, for example name@campus.edu.")
  .email("Enter a valid email address, for example name@campus.edu.");

const dateStr = (label: string) =>
  z.string().min(1, `Choose a ${label}.`).regex(/^\d{4}-\d{2}-\d{2}$/, `Choose a valid ${label}.`);

export const loginSchema = z.object({
  email,
  password: z.string().min(1, "Enter your password."),
});

export const registerSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name (at least 2 characters).").max(100, "Keep your name under 100 characters."),
  email,
  phone: z
    .string()
    .trim()
    .regex(/^\+?[0-9\s\-()]{7,20}$/, "Enter a phone number with 7–20 digits, for example +880 1712 345678."),
  department: z.string().trim().min(2, "Enter your department, for example Computer Science.").max(100),
  semester: z.coerce
    .number({ invalid_type_error: "Choose your current semester." })
    .int("Semester must be a whole number.")
    .min(1, "Semester must be between 1 and 12.")
    .max(12, "Semester must be between 1 and 12."),
  password: z
    .string()
    .min(8, "Use at least 8 characters.")
    .regex(/[A-Za-z]/, "Include at least one letter.")
    .regex(/[0-9]/, "Include at least one number."),
});

export const clubSchema = z.object({
  club_name: z.string().trim().min(3, "Enter a club name of at least 3 characters.").max(80, "Keep the name under 80 characters."),
  description: z.string().trim().min(10, "Describe the club in at least 10 characters.").max(500, "Keep the description under 500 characters."),
  category: z.string().min(1, "Choose a category."),
  email,
  established_date: dateStr("established date").refine((d) => d <= todayISO(), "The established date can't be in the future."),
  status: z.enum(["Active", "Inactive"]),
});

export const eventSchema = (isNew: boolean) =>
  z
    .object({
      club_id: z.string().min(1, "Choose the club that hosts this event."),
      event_name: z.string().trim().min(3, "Enter an event name of at least 3 characters.").max(100, "Keep the name under 100 characters."),
      description: z.string().trim().min(10, "Describe the event in at least 10 characters.").max(500, "Keep the description under 500 characters."),
      event_date: dateStr("event date").refine((d) => !isNew || d >= todayISO(), "Choose today or a future date."),
      start_time: z.string().min(1, "Choose a start time."),
      end_time: z.string().min(1, "Choose an end time."),
      venue: z.string().trim().min(2, "Enter the venue, for example Auditorium B.").max(100),
    })
    .refine((v) => !v.start_time || !v.end_time || v.end_time > v.start_time, {
      path: ["end_time"],
      message: "End time must be after the start time.",
    });

export const feedbackSchema = z.object({
  feedback: z.string().trim().min(3, "Write at least 3 characters of feedback.").max(1000, "Keep feedback under 1000 characters."),
});

export type FieldErrors = Record<string, string>;

/** Validate and return either parsed data or a map of field -> first error. */
export function validate<T>(schema: z.ZodType<T, z.ZodTypeDef, unknown>, values: unknown):
  | { ok: true; data: T }
  | { ok: false; errors: FieldErrors } {
  const result = schema.safeParse(values);
  if (result.success) return { ok: true, data: result.data };
  const errors: FieldErrors = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!errors[key]) errors[key] = issue.message;
  }
  return { ok: false, errors };
}
